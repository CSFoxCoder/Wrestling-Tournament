/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mcdonald.s.tournament;

import java.util.ArrayList;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.Border;
import javafx.scene.layout.BorderStroke;
import javafx.scene.layout.BorderStrokeStyle;
import javafx.scene.layout.BorderWidths;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;

/**
 *
 * @author lcs2
 */
public class McDonaldSTournament extends Application {
    public ObservableList <Team> teams = FXCollections.observableArrayList();
    public ObservableList<Wrestler> wrestlers = FXCollections.observableArrayList();
    public ObservableList<match> matches = FXCollections.observableArrayList();
    @Override
    public void start(Stage primaryStage) {
        //This part sets the prerequisites
        VBox master = new VBox();
        Scene scene = new Scene(master);
        primaryStage.setScene(scene);
        primaryStage.show();
        primaryStage.setFullScreen(true);
        primaryStage.setTitle("McDonald's Holiday Tournament 2018");
         //This establishes the main boxes that will hold all of the components from each tab
        HBox Home = new HBox(70);
        HBox Edit = new HBox(70);
        HBox View = new HBox(30);
        HBox TeamLeader = new HBox(30);
        Insets settings = new Insets(30,30,30,30);
        Home.setPadding(settings);
        Edit.setPadding(settings);
        View.setPadding(settings);
        TeamLeader.setPadding(settings);
        //This part handles the banner
        
            Border border = new Border(new BorderStroke(Color.BLACK,
                    BorderStrokeStyle.SOLID, new CornerRadii(10), new BorderWidths(15)));
             Border smallBorder = new Border(new BorderStroke(Color.BLACK,
                    BorderStrokeStyle.SOLID, new CornerRadii(5), new BorderWidths(7)));
            Border border2 = new Border(new BorderStroke(Color.GRAY,
                    BorderStrokeStyle.SOLID, new CornerRadii(5), new BorderWidths(5)));
            Font impact = Font.font("IMPACT", 20);
            Font smallImpact = Font.font("IMPACT", 15);
            HBox box = new HBox(75);
            box.setPadding(new Insets(15, 15, 15, 15));
            box.setPrefSize(2000, 130);
            HBox left = new HBox(15);
            HBox right = new HBox(50);
            Button home = new Button("Home");
            Button edit = new Button("Edit \nRosters");
            Button view = new Button("Bracket \nView");
            Button team = new Button("Team \nLeaderboards");
            Label label = new Label("McDonalds Holiday Tournament 2018");
            label.setStyle("-fx-background-color: gold");
            label.setPrefSize(350, 100);
            label.setTextAlignment(TextAlignment.CENTER);
            label.setBorder(border2);
            label.setPadding(new Insets(15, 15, 15, 15));
            // ImageView livePerformIcon = new ImageView();
            label.setBackground(new Background(new BackgroundImage(new Image("lava.jpg", 350, 100, false, true), BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, null, null)));
            ImageView Mcd = new ImageView(new Image("mcd.png", 150, 100, false, true));
            ImageView MT = new ImageView(new Image("mt.png", 150, 100, false, true));

            //Make the buttons look pretty
            home.setBorder(border);
            edit.setBorder(border);
            view.setBorder(border);
            team.setBorder(border);
            home.setFont(Font.font("IMPACT", 20));
            edit.setFont(Font.font("IMPACT", 20));
            view.setFont(Font.font("IMPACT", 20));
            label.setFont(Font.font("IMPACT", 20));
            team.setFont(Font.font("IMPACT", 20));
            home.setStyle("-fx-background-color: gold");
            edit.setStyle("-fx-background-color: gold");
            view.setStyle("-fx-background-color: gold");
            team.setStyle("-fx-background-color: gold");
            home.setBorder(border2);
            edit.setBorder(border2);
            view.setBorder(border2);
            team.setBorder(border2);
            home.setPrefSize(150, 100);
            edit.setPrefSize(150, 100);
            view.setPrefSize(150, 100);
            team.setPrefSize(200, 100);
            box.setStyle("-fx-background-color: black");
            //Put it all into the box
            left.getChildren().addAll(home, edit, view, team);
            right.getChildren().addAll(Mcd, MT);
            box.getChildren().addAll(left, label, right);
            master.getChildren().addAll(box,Home);
            //Set actions for all of the buttons.
            home.setOnAction(e -> {
            master.getChildren().remove(1);
            master.getChildren().addAll(Home);
            });
            edit.setOnAction(e -> {
            master.getChildren().remove(1);
            master.getChildren().addAll(Edit);
            });
            view.setOnAction(e -> {
            master.getChildren().remove(1);
            master.getChildren().addAll(View);
            });
            team.setOnAction(e -> {
            master.getChildren().remove(1);
            master.getChildren().addAll(TeamLeader);
            });
    
       
        //This part will handle the "Home" Screen
        //Here are the main components
        
            HBox inputResults = new HBox(20);
            inputResults.setBorder(border);
            inputResults.setPrefSize(300,100);
            inputResults.setPadding(new Insets(15,15,15,15));
            ListView<ArrayList<match>> upcoming = new ListView();
            ListView<ArrayList<match>> matOne = new ListView();
            ListView<ArrayList<match>> matTwo = new ListView();
            ListView<ArrayList<match>> matThree = new ListView();
            ListView<ArrayList<match>> matFour = new ListView();
            upcoming.setBorder(smallBorder);
            matOne.setBorder(smallBorder);
            matTwo.setBorder(smallBorder);
            matThree.setBorder(smallBorder);
            matFour.setBorder(smallBorder);
            //This will be where the stuff in "Input Results" will be initialized.
            
                //Title
                Label inResults = new Label("Input Results");
                inResults.setFont(impact);
                //Left Side
                VBox inputLeft = new VBox(28);
                inputLeft.setPrefSize(150,100);
                Label mNum = new Label("Match Number: ");
                Label winnerz = new Label("Winner of Match:");
                Label fallType = new Label("Fall Type*: ");
                Button info = new Button("Help");
                mNum.setFont(impact);
                winnerz.setFont(impact);
                fallType.setFont(impact);
                info.setFont(Font.font("Impact",14));
                inputLeft.getChildren().addAll(mNum, winnerz, fallType, info);
                
                //This is the help area for INPUTRESULTS
                Alert information = new Alert(AlertType.INFORMATION);
                information.setTitle("Valid Fall Types");
                information.setHeaderText("Valid Fall Types");
                information.setContentText("Pin ,DQ ,Default ,Tech ,Major Point, MP, Point");
               
                info.setOnAction(e->{
                 information.show();   
                });
               

                //Right Side
                VBox inputRight = new VBox(25);
                TextField numUpdate = new TextField();
                TextField winner = new TextField();
                TextField fType = new TextField();
                Button submit = new Button("Submit");
                submit.setFont(Font.font("impact",14));
                inputRight.getChildren().addAll(numUpdate, winner, fType,submit);
                //Put left and right sides into boxes.
                inputResults.getChildren().addAll(inputLeft,inputRight);
                //Bottom
                
                Label vMessage = new Label("Verification Message: ");
                vMessage.setFont(Font.font("Times New Roman", 12));
                Text feedback = new Text("Feedback from input results is displayed here.");
                feedback.setFont(Font.font("Times New Roman",12));
                Label upcomingLabel = new Label("Waiting for mat assignment...");
                upcomingLabel.setFont(impact);
                
                
            VBox homeLeft = new VBox(15);
            VBox spaceFiller = new VBox();
            VBox homeMiddle = new VBox(30);
            VBox homeRight = new VBox(30);
            homeLeft.setPrefSize(400,700);
            homeMiddle.setPrefSize(325,700);
            homeRight.setPrefSize(325,700);
            
            homeLeft.getChildren().addAll(inputResults,vMessage, feedback,upcomingLabel,upcoming);
            homeMiddle.getChildren().addAll(matOne,matThree);
            homeRight.getChildren().addAll(matTwo,matFour);
            
            Home.getChildren().addAll(homeLeft,homeMiddle,homeRight);
        
        
        
        //Here is the end of the "Home" Section. 
        //This now begins the "Edit Rosters" section
        
        //This creates the large structures of the "Edit" panel
        VBox editLeft = new VBox(15);
        VBox editMiddle = new VBox(15);
        VBox editRight = new VBox(30);
        editLeft.setPrefSize(300,900);
        editMiddle.setPrefSize(300,900);
        editRight.setPrefSize(400,900);
        HBox rightOne = new HBox(10);
        rightOne.setBorder(smallBorder);
        rightOne.setPadding(settings);
        VBox rightOneColumnOne = new VBox(10);
        VBox rightOneColumnTwo = new VBox(10);
        HBox rightTwo = new HBox(10);
        rightTwo.setPadding(settings);
        rightTwo.setBorder(smallBorder);
        VBox rightTwoColumnOne = new VBox(15);
        VBox rightTwoColumnTwo = new VBox(10);
        ListView LOTeams = new ListView(teams);
        ListView LOWrestlers = new ListView(wrestlers);
        ListView LOmatches = new ListView(matches);
        LOTeams.setBorder(smallBorder);
        LOWrestlers.setBorder(smallBorder);
        
        
        //This creates the small structures
        Label leftLabel = new Label("List of Teams:");
        Label middleLabel = new Label("Wrestlers on selected team.");
        Label rightLabelOne = new Label("Team Adding Panel");
        Label rightLabelTwo = new Label("Wrestler Adding Panel");
        Button removeTeam = new Button("Remove Selected Team");
        Button removeWrestler = new Button("Remove Selected Wrestler");
        Button addTeam = new Button("Add Team");
        Button addWrestler = new Button("Add Wrestler");
        leftLabel.setFont(impact);
        middleLabel.setFont(impact);
        rightLabelOne.setFont(impact);
        rightLabelTwo.setFont(impact);
        removeTeam.setFont(impact);
        removeWrestler.setFont(impact);
        addTeam.setFont(impact);
        addWrestler.setFont(impact);
        //For the adding boxes
        Label nameLabelOne = new Label("Name: ");
        Label nameLabelTwo = new Label("Name: ");
        Label teamLabel = new Label("Team: ");
        Label wcLabel = new Label("Weight Class: ");
        TextField teamNameBox = new TextField("Enter the team's name");
        TextField wrestlerNameBox = new TextField("Enter the wrestler's name");
        ComboBox teamSelect = new ComboBox(teams);
        //Need to add the weight class input
        //Add things to the java boxes, starting from the bottom up
        rightOneColumnOne.getChildren().addAll(nameLabelOne);
        rightOneColumnTwo.getChildren().addAll(teamNameBox, addTeam);
        rightOne.getChildren().addAll(rightOneColumnOne,rightOneColumnTwo);
        rightTwoColumnOne.getChildren().addAll(nameLabelTwo,teamLabel,wcLabel);
        rightTwoColumnTwo.getChildren().addAll(wrestlerNameBox, teamSelect, addWrestler);
        rightTwo.getChildren().addAll(rightTwoColumnOne,rightTwoColumnTwo);
        //Now that the two small boxes on the right are finished, I will now add those and the buttons associated to the right and other panels
        editRight.getChildren().addAll(rightLabelOne,rightOne,rightLabelTwo,rightTwo);
        editMiddle.getChildren().addAll(middleLabel, LOWrestlers,removeWrestler);
        editLeft.getChildren().addAll(leftLabel,LOTeams,removeTeam);
        //Now, to the topmost panel of edit
        Edit.getChildren().addAll(editLeft,editMiddle,editRight);
        
        //This part will begin the Bracket View portion
        
        //This part will begin the leaderboards portion.
        VBox resultsLeft = new VBox(15);
        VBox resultsMiddle = new VBox(15);
        VBox resultsRight = new VBox(15);
        resultsLeft.setPrefSize(300,900);
        resultsMiddle.setPrefSize(300,900);
        resultsRight.setPrefSize(400,900);
        
        //Left
        Text resultsLeftOne = new Text("Ranking by weightclass");
        Text resultsLeftTwo = new Text("Choose Weightclass:");
        ComboBox chooseWC = new ComboBox();
        ListView weightRank = new ListView();
        resultsLeftOne.setFont(impact);
        resultsLeftTwo.setFont(impact);
        weightRank.setBorder(smallBorder);
        resultsLeft.getChildren().addAll(resultsLeftOne,resultsLeftTwo,chooseWC,weightRank);
        
        //Middle
        Text resultsMiddleOne = new Text("Player ranking by team");
        Text resultsMiddleTwo = new Text("Choose Team");
        ComboBox chooseTeam = new ComboBox();
        ListView teamRank = new ListView();
        resultsMiddleOne.setFont(impact);
        resultsMiddleTwo.setFont(impact);
        teamRank.setBorder(smallBorder);
        resultsMiddle.getChildren().addAll(resultsMiddleOne,resultsMiddleTwo,chooseTeam,teamRank);
        
        //Right
        Text resultsRightOne = new Text("Team Leaderboard");
        ListView rank = new ListView();
        resultsRightOne.setFont(impact);
        rank.setBorder(smallBorder);
        rank.setPrefSize(400,900);
        resultsRight.getChildren().addAll(resultsRightOne,rank);
        //Bring it all together
        TeamLeader.getChildren().addAll(resultsLeft,resultsMiddle,resultsRight);
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

}
