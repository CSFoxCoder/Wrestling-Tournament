/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mcdonald.s.tournament;

import javafx.application.Application;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.layout.Border;
import javafx.scene.layout.BorderStroke;
import javafx.scene.layout.BorderStrokeStyle;
import javafx.scene.layout.BorderWidths;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

/**
 *
 * @author lcs2
 */
public class Banner extends Pane {
public Banner(){
  super();
  HBox box = new HBox(10);
  //Create all of the different bases
  Button home = new Button("Home");
  Button edit = new Button("Edit Rosters");
  Button view = new Button("Bracket View");
  ImageView Mcd = new ImageView(new Image("mcd.jpg"));
  ImageView MT = new ImageView(new Image("mt.png"));
  //Make the buttons look pretty
  Border border = new Border(new BorderStroke(Color.BLACK, 
            BorderStrokeStyle.SOLID, CornerRadii.EMPTY, BorderWidths.DEFAULT));
  home.setBorder(border);
  edit.setBorder(border);
  view.setBorder(border);
  box.setStyle("-fx-background-color: black");
  //Put it all into the box
  box.getChildren().addAll(home,edit,view, Mcd, MT);
}
}