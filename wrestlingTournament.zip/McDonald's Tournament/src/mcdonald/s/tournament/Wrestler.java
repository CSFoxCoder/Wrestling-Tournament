/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mcdonald.s.tournament;

/**
 *
 * @author slaya
 */
public class Wrestler {
    private int wins;
    private int losses;
    private String name;
    private Team team;
    public Wrestler(String name, Team team){
        this.name = name;
        this.team = team;
        wins = 0;
        losses = 0;
    }
    public boolean isWinner(){
     wins++;
     return true;
    }
    public boolean isLoser(){
     losses++;
     return true;
    }
    public String getName(){
        return name;
    }
    public int getWins(){
        return wins;
    }
    public int getLosses(){
        return losses;
    }
    public Team getTeam(){
        return this.team;
    }
}
