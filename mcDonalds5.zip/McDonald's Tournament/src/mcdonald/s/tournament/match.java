/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mcdonald.s.tournament;

import java.io.Serializable;

/**
 *
 * @author lcs2
 */
public class match implements Serializable{

    private Wrestler green;
    private Wrestler red;
    private Wrestler winner;
    private Wrestler loser;
    private String status;
    private int greenPoint;
    private int redPoint;
    private boolean isFinished;

    public match(Wrestler green, Wrestler red) {
        this.green = green;
        this.red = red;
        greenPoint = 0;
        redPoint = 0;
        isFinished = false;
        status = "Waiting on a mat...";
    }

    public match(Wrestler green) {
        this.winner = green;
        isFinished = true;
        status = "BYE";
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getStatus() {
        return status;
    }

    public String done(Wrestler winner, Wrestler loser, String outcome) {
        String rs = ""; //rs = returnString
        if (green.getName().equals(winner.getName())) {
            this.winner = green;
            this.loser = red;
        } else if (red.getName().equals(loser.getName())) {
            this.winner = red;
            this.loser = green;
        } else {
            return "The name provided does match either of the partcipants in this match: " + green.getName() + " " + red.getName();
        }
        if (outcome.equalsIgnoreCase("Pin") || outcome.equalsIgnoreCase("Tech") || outcome.equalsIgnoreCase("Point") || outcome.equalsIgnoreCase("Major Decision") || outcome.equalsIgnoreCase("MP") || outcome.equalsIgnoreCase("DQ") || outcome.equalsIgnoreCase("default") || outcome.equalsIgnoreCase("forfeit")) {
            status = outcome;
            rs = rs + green.getName() + " has defeated " + red.getName() + " by " + outcome;
            isFinished = true;
            if(addTeamPoints()){;
            return rs;
            }else{
             return "Something went wrong with the adding of points.";            }
        } else {
            winner = null;
            loser = null;
            return "The outcome provided is not a 'Pin', 'Tech', or 'Point', no data has been changed.";
        }
    }

    public boolean addTeamPoints() {
        if (status.equalsIgnoreCase("Pin") || status.equalsIgnoreCase("DQ") || status.equalsIgnoreCase("default") || status.equalsIgnoreCase("forfeit")) {
            winner.getTeam().addPoints(6);
        } else if (status.equalsIgnoreCase("Tech")) {
            winner.getTeam().addPoints(5);
        } else if (status.equalsIgnoreCase("Major Point") || status.equalsIgnoreCase("MP")) {
            winner.getTeam().addPoints(4);
        } else if (status.equalsIgnoreCase("Point")) {
            winner.getTeam().addPoints(3);
        } else {
            return false;
        }
        return true;
    }

    public String toString(){
        return green.getName() + " vs. " + red.getName();
    }
}
