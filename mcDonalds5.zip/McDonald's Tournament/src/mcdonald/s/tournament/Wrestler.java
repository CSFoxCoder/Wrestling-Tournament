/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mcdonald.s.tournament;

import java.io.Serializable;

/**
 *
 * @author slaya
 */
public class Wrestler implements Comparable, Serializable{

    private int wins;
    private int losses;
    private int points;
    private String name;
    private Team team;
    private int weightClass;
    int sortMethod; //0=Name, 1=Weight Class and rank, 2=Rank

    public Wrestler(String name, Team team, int weightClass) {
        this.name = name;
        this.team = team;
        this.weightClass = weightClass;
        sortMethod = 0;
        points = 0;
        wins = 0;
        losses = 0;
    }

    public boolean isWinner() {
        wins++;
        return true;
    }

    public boolean isLoser() {
        losses++;
        return true;
    }

    public String getName() {
        return name;
    }

    public String getMatchInfo() {
        return name + " <" + team.getAC() + "> (" + wins + "-" + losses + ")";
    }

    public int getWins() {
        return wins;
    }

    public int getLosses() {
        return losses;
    }

    public Team getTeam() {
        return this.team;
    }

    public int getWeightClass() {
        return weightClass;
    }

    public int getPoints() {
        return points;
    }

    public boolean setSort(int n) {
        sortMethod = n;
        return true;
    }

    @Override
    public String toString() {
        return name + ": " + points + "(" + wins + "-" + losses + ")";
    }

    @Override
    public int compareTo(Object t) {
        Wrestler comp = (Wrestler) t;
        if (sortMethod == 0) {
            if (name.compareTo(comp.getName()) > 0) {
                return 1;
            } else if (name.compareTo(comp.getName()) == 0) {
                return 0;
            } else {
                return -1;
            }
        } 
        else if (sortMethod == 1) {
            if (weightClass < comp.getWeightClass()) {
                return 1;
            } else if (weightClass == comp.getWeightClass()) {
                if (points > comp.getPoints()) {
                    return 1;
                } else if (points == comp.getPoints()) {
                    return 0;
                } else {
                    return -1;
                }
            } else {
                return -1;
            }

        }
        else{
            if(points > comp.getPoints()){
                return 1;
            }else if(points == comp.getPoints()){
               return 0;
            } else{
               return -1;
            }
        }
    }
}
